package com.example.myapplication.ui.setting;

import android.app.Activity;
import android.os.Bundle;
import android.util.DisplayMetrics;

import com.example.myapplication.R;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Pop extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }
}
